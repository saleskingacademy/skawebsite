# Sales King Academy Fullstack Repository (feature)

This is the feature branch for experimental changes.

## Getting Started
1. Navigate to the root directory.
2. For frontend:
   - Serve `frontend/index.html` using any static server.
3. For backend:
   ```bash
   cd backend
   npm install
   npm start
   ```